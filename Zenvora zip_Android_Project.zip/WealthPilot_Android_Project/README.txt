WEALTHPILOT PRO - ANDROID PROJECT

This is an Android Studio project wrapping the supplied WealthPilot Pro mobile web prototype
inside a native Android WebView. The app does not move real money.

Build:
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Run on an Android phone/emulator, or choose Build > Build APK(s).

The original prototype is in:
app/src/main/assets/index.html
